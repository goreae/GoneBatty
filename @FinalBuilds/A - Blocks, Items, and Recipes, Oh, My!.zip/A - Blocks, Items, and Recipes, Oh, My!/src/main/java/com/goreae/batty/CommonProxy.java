package com.goreae.batty;

public class CommonProxy {
	
	public void registerRenderers() 
	{
		
	}
}
